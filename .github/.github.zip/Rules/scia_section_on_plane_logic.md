# SCIA Section on Plane Logic Documentation

## Overview

This document explains how the `scia_section_on_plane.py` module creates 2D section planes for bridge analysis in SCIA Engineer. Section planes are used to extract internal forces and stresses at specific locations in the 3D bridge model.

The module implements a sophisticated grid system that adapts to:
- **Intermediate segment boundaries** within spans
- **Zone boundaries** between different bridge cross-section zones (bz1, bz2, bz3)
- **Special cases** for narrow middle zones (bz2 ≤ 1.002m)

## Key Concepts

### Section Types

The module creates two types of section planes:

1. **X-direction sections** (horizontal, extending in x-direction)
   - Fixed length: 1.0m in the x-direction
   - Positioned at different y-coordinates across the bridge width
   - Spaced every 0.5m in both x and y directions

2. **Y-direction sections** (vertical, extending downward in y-direction)
   - Fixed length: 1.0m in the y-direction (downward from start point)
   - Positioned at different x-coordinates along the bridge length
   - Spaced every 0.5m in both x and y directions

### Bridge Geometry

**Coordinate System**:
- X-axis: Along bridge length (longitudinal)
- Y-axis: Across bridge width (transverse), positive upward
- Z-axis: Horizontal perpendicular to bridge axis

**Zone Structure** (in y-direction):
```
        y = bz2/2 + bz1
    ┌─────────────────┐
    │      bz1        │ (Top zone)
    ├─────────────────┤ ← Zone boundary 1: y = bz2/2
    │      bz2        │ (Middle zone, centered at y=0)
    ├─────────────────┤ ← Zone boundary 2: y = -bz2/2
    │      bz3        │ (Bottom zone)
    └─────────────────┘
        y = -(bz2/2 + bz3)
```

**Span Structure** (in x-direction):
- A span is defined by two supports (start and end)
- May contain intermediate segments without supports
- Each segment boundary is tracked as an `intermediate_segment_x_position`

## Constants

Defined in `src/integrations/scia_integration/constants/geometry.py`:

- **SECTION_ON_PLANE_LENGTH**: 1.0m - length of each section
- **SECTION_ON_PLANE_SPACING**: 0.5m - spacing between section positions
- **SECTION_ON_PLANE_OFFSET_FACTOR**: 0.9 - edge offset factor (0.9 × min_thickness)
- **SECTION_ON_PLANE_INTERMEDIATE_OFFSET**: 0.001m (1mm) - offset from boundaries
- **SECTION_ON_PLANE_TOLERANCE**: 0.01m (10mm) - tolerance for boundary detection

## Section Creation Algorithm

### Step 1: Span Identification

The `_identify_spans()` function groups segments into spans:
- A span starts with a segment where `is_first_segment == True`
- Continues until the next segment with `is_first_segment == True` or end of segments
- For each span, calculates:
  - `num_segment_definitions`: Count of segment definition points (including start/end supports)
  - `intermediate_segment_x_positions`: X-coordinates of intermediate boundaries

Example:
```
Segments: [seg0 (l=0, is_first=True), seg1 (l=3m), seg2 (l=5m)]
→ Span with 3 segment definitions at x = [0, 3, 8]m
→ Intermediate boundaries at x = [3]m
```

### Step 2: X-Direction Section Generation

For each span:

1. **Generate initial x-positions**:
   - Start: `x_start_limit + OFFSET_FACTOR × min_thickness`
   - End: `x_end_limit - OFFSET_FACTOR × min_thickness`
   - Spacing: Every 0.5m
   - Uses `_generate_positions_with_spacing()` with `section_extends_forward=True`

2. **Filter for intermediate segment boundaries** (if `num_segment_definitions > 2`):
   - Uses unified `_filter_positions_for_boundaries()` function
   - Creates `Boundary` objects for each intermediate segment position
   - Creates `Section` objects to check for crossings
   - Removes sections that cross intermediate boundaries
   - Adds edge sections ending 0.001m before each boundary
   - Adds edge sections starting 0.001m after each boundary
   - Applies strict tolerance (0.0005m) filtering to prevent boundary touching

3. **Generate y-positions** (where to place x-direction sections):
   - Start: `y_top` (outer edge of bz1)
   - End: `y_bottom` (outer edge of bz3)
   - Spacing: Every 0.5m downward
   - Uses `_generate_positions_with_spacing()` with `section_extends_forward=False`

4. **Filter y-positions for zone boundaries**:
   - Uses unified `_filter_positions_for_boundaries()` function
   - Creates `Boundary` objects for zone boundaries (bz1/bz2 and bz2/bz3)
   - For x-direction sections: positions are point-like (not extending), uses `Section.is_near_boundary()`
   - Removes positions on or too close to boundaries
   - Adds positions at `boundary ± 0.001m`

5. **Special handling for narrow bz2** (if `bz2 ≤ 1.002m`):
   - Add x-direction sections at y=0 (centerline of bz2)
   - Uses all x-positions respecting intermediate boundaries

6. **Create section definitions**:
   - For each (x_pos, y_pos) combination
   - Section extends from `x_pos` to `x_pos + 1.0m`
   - Positioned at height `y_pos`
   - Creates `SectionOnPlaneDefinition` Pydantic model with validation

### Step 3: Y-Direction Section Generation

For each span:

1. **Generate initial x-positions** (where to place y-direction sections):
   - Same as x-direction positions
   - Uses `_generate_positions_with_spacing()` with `section_extends_forward=False`
   - Also filtered for intermediate boundaries if needed using `_filter_positions_for_boundaries()`

2. **Generate y-positions** (starting points for downward sections):
   - Start: `y_top`
   - End: `y_bottom + section_length` (so bottom reaches `y_bottom`)
   - Spacing: Every 0.5m
   - Uses `_generate_positions_with_spacing()` with `section_extends_forward=True`

3. **Filter and adjust for zone boundaries**:
   - Uses unified `_filter_positions_for_boundaries()` function
   - Creates `Boundary` objects for zone boundaries
   - Creates `Section` objects with `direction="y"` to check for crossings
   - Removes sections that start/end exactly on boundaries (using `Section.crosses_or_touches_boundary()`)
   - Removes sections that cross boundaries
   - Adds edge sections at each boundary:
     - Section ending 0.001m above boundary (end = boundary + offset)
     - Section starting 0.001m below boundary (start = boundary - offset)
   - **Strict tolerance check** (0.0005m): Final filter to remove sections within 0.0005m of boundaries
     - Allows intentional 0.001m offset sections to pass
     - Blocks unintentional boundary-touching sections from rounding errors

4. **Special handling for narrow bz2** (if `bz2 ≤ 1.002m`):
   - Add y-direction sections spanning the full height of bz2
   - Start: `(bz2/2) - 0.001m` (just below top boundary)
   - End: `(-bz2/2) + 0.001m` (just above bottom boundary)
   - Length: approximately `bz2 - 0.002m`
   - Uses x-positions respecting intermediate boundaries

5. **Create section definitions**:
   - For each (x_pos, y_pos) combination
   - Section extends downward from `y_pos` to `y_pos - 1.0m`
   - Positioned at `x_pos`
   - Creates `SectionOnPlaneDefinition` Pydantic model with validation

## Boundary Handling Details

The refactored code uses a unified `_filter_positions_for_boundaries()` function that handles both intermediate segment boundaries and zone boundaries for both x and y directions.

### Unified Boundary Filtering Function

**Function**: `_filter_positions_for_boundaries(positions, boundaries, section_length, section_direction, tolerance, extends_forward)`

**Parameters**:
- `positions`: List of positions to filter
- `boundaries`: List of `Boundary` Pydantic models (with position, offset, boundary_type)
- `section_length`: Length of sections (1.0m for regular sections, 0 for point positions)
- `section_direction`: "x" or "y" - direction of section extension
- `tolerance`: Regular tolerance for initial filtering (0.01m)
- `extends_forward`: Boolean indicating if sections extend forward from position

**Process**:
1. Create `Section` Pydantic models to represent each potential section
2. Check each section against all boundaries using `Section.crosses_or_touches_boundary()`
3. For point positions (section_length=0), use `Section.is_near_boundary()` instead
4. Remove sections that conflict with boundaries
5. Generate edge sections near boundaries to maintain coverage
6. Apply strict tolerance filtering (0.0005m) to catch rounding errors
7. Return filtered and augmented position list

### Intermediate Segment Boundaries (X-Direction)

**Problem**: Sections cannot cross segment boundaries where material properties or geometry change.

**Solution**: Applied via `_filter_positions_for_boundaries()` with intermediate segment boundaries
1. Create `Boundary(position=x, offset=0.001, boundary_type="segment")` for each intermediate position
2. Create `Section(start=pos, end=pos+1.0, direction="x")` for each potential x-position
3. Check if `Section.crosses_or_touches_boundary(boundary.position, tolerance)`
4. If crossing detected:
   - Calculate edge position ending before: `start = boundary.position - offset - section_length`
   - Calculate edge position starting after: `start = boundary.position + offset`
5. Apply strict tolerance (0.0005m) to remove any remaining sections within 0.5mm of boundaries
6. Edge sections at exactly 1mm offset (0.001m) pass the strict tolerance check

**Example**:
```
Regular section at x=2.5m would span [2.5, 3.5]m
Boundary at x=3.0m with offset=0.001m
→ Section crosses boundary (3.0 is between 2.5 and 3.5 with margin)
→ Replace with:
   - Section starting at 3.0 - 0.001 - 1.0 = 1.999m, ending at 2.999m
   - Section starting at 3.0 + 0.001 = 3.001m, ending at 4.001m
```

### Zone Boundaries (Y-Direction)

**Problem**: X-direction sections at certain y-coordinates would cross zone boundaries. Y-direction sections extending downward might cross zone boundaries.

**Solution for X-direction sections**: Uses `_filter_positions_for_boundaries()` with point positions
1. Create `Boundary(position=y, offset=0.001, boundary_type="zone")` for each zone boundary
2. Create `Section(start=pos, end=pos, direction="x")` (point-like, no extension)
3. Use `Section.is_near_boundary(boundary.position, offset)` to check proximity
4. Remove positions within offset of boundaries
5. Add positions at `boundary.position ± offset`

**Solution for Y-direction sections**: Uses `_filter_positions_for_boundaries()` with extending sections
1. Create `Boundary(position=y, offset=0.001, boundary_type="zone")` for each zone boundary
2. Create `Section(start=pos, end=pos-1.0, direction="y")` for each potential y-position
3. Check if `Section.crosses_or_touches_boundary(boundary.position, tolerance)`
   - Handles downward sections where start > end using min/max logic
4. If crossing detected:
   - Calculate edge position ending above: `start = boundary.position + offset + section_length`
   - Calculate edge position starting below: `start = boundary.position - offset`
5. Apply strict tolerance (0.0005m) to remove sections within 0.5mm of boundaries
6. Edge sections at exactly 1mm offset pass the strict tolerance check

**Example (Y-direction):**
```
Zone boundary at y=0.25m (bz1/bz2) with offset=0.001m
Regular sections might be at y=[1.25, 0.75, 0.25, -0.25, -0.75]m

After filtering:
- Remove y=0.25m (on boundary, within tolerance)
- Section at y=0.75m extends to -0.25m → CROSSES boundary at 0.25m → REMOVED
- Add edge section ending above: start = 0.25 + 0.001 + 1.0 = 1.251m, end = 0.251m
- Add edge section starting below: start = 0.25 - 0.001 = 0.249m, end = -0.751m
→ Edge section at 0.249m crosses lower boundary at -0.25m → REMOVED in strict check
→ Final: [1.251, 1.25, 0.251, -0.25, -0.75]m (approximately, after all filtering)
```

## Special Case: Narrow bz2 Zones

When `bz2 ≤ 1.002m`, the middle zone is too narrow for regular section coverage. The module adds special sections:

### Special X-Direction Sections
- Positioned at y=0 (centerline of bz2)
- Uses all x-positions (respecting intermediate segment boundaries)
- Provides horizontal coverage through the middle zone

### Special Y-Direction Sections
- Span the full interior height of bz2
- Start: `y = (bz2/2) - 0.001m` ≈ 0.249m (for bz2=0.5m)
- End: `y = (-bz2/2) + 0.001m` ≈ -0.249m (for bz2=0.5m)
- Section length: approximately `bz2 - 0.002m` ≈ 0.498m
- Uses x-positions respecting intermediate boundaries
- Provides vertical coverage through the narrow middle zone

**Rationale**: With regular 1.0m sections and 0.5m spacing, a zone narrower than 1.002m cannot fit regular sections without crossing boundaries. These special shorter sections ensure complete coverage.

## Code Structure

### Main Functions

- **`create_section_definitions(params)`**: Main entry point
  - Identifies spans
  - Creates x-direction and y-direction sections for each span
  - Applies all filtering and boundary handling
  - Returns list of `SectionOnPlaneDefinition` objects

- **`create_all_sections_on_plane(params, model_builder)`**: Wrapper function
  - Calls `create_section_definitions()`
  - Uses SCIA model builder to add sections to model

### Core Helper Functions

- **`_identify_spans(segments)`**: Groups segments into spans based on support locations
- **`_create_span_from_segments(...)`**: Creates `Span` Pydantic model from segment list
- **`_generate_positions_with_spacing(...)`**: Generates regularly spaced positions with boundary considerations
- **`_filter_positions_for_boundaries(...)`**: Unified function handling boundary filtering and edge section generation
  - Works for both x-direction and y-direction sections
  - Uses `Boundary` and `Section` Pydantic models for type-safe validation
  - Handles intermediate segment boundaries and zone boundaries
  - Adds edge sections near boundaries to maintain coverage
  - Applies strict tolerance filtering to prevent boundary crossings

### Pydantic Data Models (in `src/data_models/scia_models.py`)

- **`Span`**: Represents a bridge span with validated geometric properties
  - Fields: start_x, end_x, length, width, bz1, bz2, bz3, min_thickness, span_index
  - `num_segment_definitions`: Count of segment definition points
  - `intermediate_segment_x_positions`: List of intermediate boundary x-coordinates
  - Validates geometric consistency (length matches coordinates, zones sum to width)

- **`Boundary`**: Represents a boundary with position and offset
  - Fields: position, offset, boundary_type ("segment" or "zone")
  - Method: `get_positions_at_boundary()` returns (before, after) positions with offset

- **`Section`**: Represents a section plane segment
  - Fields: start, end, direction ("x" or "y")
  - Method: `crosses_or_touches_boundary()` checks if section conflicts with boundary
  - Method: `is_near_boundary()` checks if section is within offset of boundary
  - Handles both forward-extending and backward-extending sections

- **`SectionOnPlaneDefinition`**: Final section plane definition
  - Fields: name, point_1, point_2, draw, direction_of_cut
  - Validates coordinate ranges and geometric consistency

## Tolerance Management

The module uses two tolerance values:

1. **SECTION_ON_PLANE_TOLERANCE** (0.01m):
   - Used for initial boundary detection
   - Determines if a section is "close enough" to a boundary to be considered problematic

2. **Strict Tolerance** (0.0005m):
   - Used in final filtering for y-direction sections
   - Calculated as `SECTION_ON_PLANE_INTERMEDIATE_OFFSET / 2`
   - Blocks sections within 0.5mm of boundaries
   - Allows sections exactly 1mm offset from boundaries

This two-tier system ensures:
- Intentional offset sections (at 1mm) are preserved
- Accidental boundary-touching sections are removed
- No sections end up exactly on boundaries

## Example: Complete Section Generation

For a span with:
- Length: 8m (x: 0 to 8m)
- bz1 = 2.0m, bz2 = 0.5m, bz3 = 4.2m
- 3 segment definitions at x = [0, 3, 8]m (intermediate boundary at x=3m)
- min_thickness = 0.3m

**Zone boundaries**:
- bz1/bz2: y = 0.5/2 = 0.25m
- bz2/bz3: y = -0.5/2 = -0.25m

**X-direction sections**:
1. X-positions (initial): [0.27, 0.77, 1.27, ..., 7.73]m (spacing 0.5m, edge offset 0.9×0.3=0.27m)
2. X-positions (after filtering for x=3m boundary): [0.27, 0.77, ..., 2.27, 2.999, 3.001, 3.501, ..., 7.73]m
3. Y-positions: [2.25, 1.75, ..., 0.251, 0.249, -0.249, -0.251, ..., -4.45]m (with boundary offsets)
4. Special sections at y=0 (bz2 ≤ 1.002m): All x-positions × y=0
5. Total: Approximately 13 x-positions × 17 y-positions = 221 x-direction sections

**Y-direction sections**:
1. X-positions: Same as x-direction (filtered for intermediate boundary)
2. Y-positions (initial): [2.25, 1.75, ..., -3.45]m
3. Y-positions (after zone boundary filtering + edge sections): Approximately 11 positions
4. Special spanning sections (bz2 ≤ 1.002m): 13 x-positions × 1 special y-section
5. Total: Approximately (13 × 11) + 13 = 156 y-direction sections

**Grand total**: Approximately 377 section definitions for this span

## Related Files

- **Implementation**: `src/integrations/scia_integration/model/scia_section_on_plane.py`
- **Constants**: `src/integrations/scia_integration/constants/geometry.py`
- **Pydantic Models**: `src/data_models/scia_models.py` (`SectionOnPlaneDefinition`, `Span`, `Boundary`, `Section`)
- **Unit Tests**: `tests/test_src/test_scia_section_on_plane.py`
- **Usage Example**: `app/bridge/scia_model_builder.py` (calls via `define_complete_bridge_model()`)

## Version History

- **Initial implementation**: Basic section grid with regular spacing
- **Intermediate boundary support**: Added filtering for multi-segment spans  
- **Zone boundary support**: Added filtering for zone boundaries
- **Narrow bz2 support**: Added special sections for zones ≤ 1.002m wide
- **Strict tolerance**: Added two-tier tolerance system for precise boundary handling
- **Refactoring (2024)**: 
  - Unified boundary filtering logic in `_filter_positions_for_boundaries()`
  - Migrated to Pydantic models for type safety (`Boundary`, `Section`, `Span`)
  - Improved code maintainability with shared logic for x and y directions
  - Added comprehensive unit test suite (11 tests covering crossing detection, boundary models, edge sections)
